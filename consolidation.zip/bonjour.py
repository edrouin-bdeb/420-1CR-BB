#!/usr/bin/env python3

import os
import pwd

nom_utilisateur = os.getlogin()
utilisateur = pwd.getpwnam(nom_utilisateur) 

print(f"Bonjour {utilisateur.pw_gecos}!")
