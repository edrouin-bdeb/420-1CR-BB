#!/usr/bin/env python3

import os
import shutil
import time


def deplacer_chat() -> None:
    largeur = shutil.get_terminal_size().columns

    while True:
        for i in range(largeur):
            os.system('clear')
            print(" " * i + "🐱")
            print("\nCTRL-C pour arrêter")
            time.sleep(0.05)


if __name__ == '__main__':
    try:
        deplacer_chat()
    except KeyboardInterrupt:
        pass

