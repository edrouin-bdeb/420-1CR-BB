#!/usr/bin/env python3

import random
import signal
import time


def handler(signum, frame):
    pass


def clavier_hante() -> None:
    phrase = "Bonjour, je suis le clavier hanté!\nIci, il faut savoir patienter."
    for lettre in phrase:
        print(lettre, end='', flush=True)
        attente = random.uniform(0.1, 0.25)
        time.sleep(attente)
    print()


if __name__ == "__main__":
    signal.signal(signal.SIGINT, handler)
    clavier_hante()    

