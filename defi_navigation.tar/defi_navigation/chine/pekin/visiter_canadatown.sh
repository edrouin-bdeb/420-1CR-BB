#!/usr/bin/bash

res=../../.res

echo "L'office du tourisme de Pékin vous apprend qu'il existe un quartier"
echo "canadien dans la ville: Canadatown! Et bien, vous n'êtes pas au bout"
echo "des surprises... Vous vous rendez donc dans Canadatown à la recherche"

if [[ -f "$res/producteur.$USER" ]]
then
  echo "d'un antiquaire... Vous le trouvez assez rapidement dans le demi-"
  echo "sous-sol d'une épicerie qui vend du sirop d'érable, du beurre"
  echo "d'arachides, du fromage en crottes et du boeuf Angus triple A"
  echo "d'Alberta."
  echo ""
  echo -e "\"$PRENOM Bourne. Je ne vous attendais pas de si tôt. Je devrais"
  echo "normalement engager un combat à mort avec vous pour protéger cette"
  echo "clé USB, mais j'ai vu beaucoup de film d'espionnage dans ma vie et"
  echo "je sais pertinemment que mes chances de victoire sont nulles même"
  echo "si je suis ceinture noire 5eme dan et triple champion du monde en"
  echo -e "combat ultime. Félicitations, vous avez réussi le défi.\""
  echo ""
  echo "Vous acceptez la clé USB avec une certaine fierté. On vous remet"
  echo "un bouquet, une peluche, une médaille, un trophée, une assiette,"
  echo "un ruban, un certificat, un vase et une épinglette. Vous rentrez"
  echo "à la maison avec le sentiment du devoir accompli. Bravo!"
  . $res/nettoyer.sh
  cd ~
else
  echo "de rien en particulier, ce que vous trouvez assez facilement."
fi
