#!/usr/bin/bash

res=../../.res

if [[ -f "$res/magnus.$USER" ]]
then
  echo "Vous prenez un vol vers Toronto."

  rm $res/magnus.$USER
  touch $res/toronto.$USER

  cd ../../canada/toronto
else
  echo "Vous prenez un vol vers Istanbul."
  cd ../../turquie/istanbul
fi
