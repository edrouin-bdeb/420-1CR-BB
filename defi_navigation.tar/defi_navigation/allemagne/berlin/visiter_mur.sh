#!/usr/bin/bash

echo "A) Vous montez à bord d'une machine à remonter le temps et visitez le mur de Berlin."
echo "B) Vous visitez l'emplacement où se trouvait le mur de Berlin."
echo "C) Vous reconstruisez un mur, puis vous le visitez."
echo ""
echo "Non, on ne s'attend pas vraiment à obtenir une réponse de votre part..."
echo "Vous n'avez pas une enquête à mener?"
