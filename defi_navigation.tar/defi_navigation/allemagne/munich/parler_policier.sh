#!/usr/bin/bash

echo "Vous attrapez un policier qui passait par là et vous lui posez des"
echo "questions au sujet d'un cadavre découvert sous une table."
echo "Le policier vous regarde..."
sleep 3
echo "...puis vous répond que CE N'EST PAS DE VOS AFFAIRES."
echo "Il ajoute que vous feriez mieux de filer."
