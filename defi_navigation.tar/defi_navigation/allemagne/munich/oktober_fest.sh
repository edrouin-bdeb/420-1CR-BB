#!/usr/bin/bash

echo "Vous vous rendez sur les lieux de l'Oktoberfest."
cat ../../.res/hotdog.txt
echo "Tout ce qu'il en reste, ce sont les souvenirs d'un bon hot dog."
echo "Vous vous attendiez à quoi exactement?"
