#!/usr/bin/bash

echo "Bienvenue dans le défi navigation"

permis="^[A-Z][A-Za-z -]*$"
prenom="*** non permis ***"

while [[ ! $prenom =~ $permis ]]
do
  read -p "Quel est votre prénom? " prenom
  if [[ ! $prenom =~ $permis ]]
  then
    echo "Désolé, seuls les lettres (sans accent), espaces et tiraits sont acceptés. Doit commencer par une majuscule."
  fi
done

config_file=~/.bashrc
cp $config_file $config_file~~

if [[ -f "$config_file" ]]
then
  retour=`grep "export PRENOM=" $config_file`
else
  retour=""
fi

if [[ $retour != "" ]]
then
  sed -i s/PRENOM=.*/PRENOM=$prenom/g $config_file
else
  echo "export PRENOM=$prenom" >> $config_file
fi

export PRENOM=$prenom
cp .res/mission.txt .
sed -i s/PRENOM/$prenom/g mission.txt

echo "Affichez votre mission à l'aide de la commande cat."
