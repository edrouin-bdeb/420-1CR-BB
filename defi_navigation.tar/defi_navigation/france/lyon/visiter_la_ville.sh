#!/usr/bin/bash

res=../../.res

echo "Vous décidez de visiter la ville."

if [[ -f "$res/papier.$USER" ]]
then
  echo "Vous marchez... Il y a des gens partout, mais vous ne reconnaissez personne."
  sleep 2
  echo "Vous marchez encore un peu plus loin."
  sleep 5
  echo "Vous vous dites que ça paraissait moins loin..."
  sleep 2
  echo "Vous apercevez un vieux barbu assis à un café, la copie conforme de l'autre druide."
  echo "Vous vous asseyez à sa table, puis soutenez son regard."
  sleep 4
  echo "Une voiture passe dans la rue."
  sleep 5
  echo "Le vieux vous fixe toujours sans cligner des yeux. Vous lui rendez la pareille."
  sleep 3
  echo "Une bicyclette passe dans la rue."
  sleep 5
  echo "Le vieux ouvre la bouche..."
  sleep 3
  echo "...et prononce..." 
  sleep 4
  echo "   Aller cacahuète... Il est tellllllleement lent!"
  sleep 7
  echo "...un nom: Francesco del Giocondo" 
  sleep 2
  echo "Ouf! C'est ce qui s'appelle obtenir de l'information par la torture."
  echo "Le frère de l'autre vous salue alors que vous vous levez de la table et quittez."
  echo "Il n'a toujours pas cligné des yeux." 
  rm $res/papier.$USER
  touch $res/giocondo.$USER
else
  echo "Vous arpentez la ville pendant des heures. C'est beau, mais ça ne vous avance à rien."
fi
