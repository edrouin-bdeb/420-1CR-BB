#!/usr/bin/bash

res=../../.res

echo "Vous visitez le musée du Louvre et admirez les oeuvres des grands maîtres."

if [[ -f "$res/giocondo.$USER" ]]
then
  echo "Alors que vous tentez d'apercevoir la Joconde derrière une horde de dépendants du selfie,"
  echo "un gardien de sécurité s'approche de vous: \"veuillez me suivre svp.\""
  echo ""
  echo "Vous acceptez de le suivre alors qu'il vous guide vers une porte dérobée au fond de la pièce."
  echo ""
  read -n 1 -s -r -p "Appuyez sur une touche pour entrer dans la pièce."
  echo -e "\n"
  echo "Le gardien: \"Je sais pourquoi vous êtes ici,"
  echo "             $PRENOM Bourne."
  cat $res/gardien.txt
  rm $res/giocondo.$USER
  touch $res/mama.$USER
else
  echo "Nous vous pressez surtout pas. Ce n'est pas comme si vous étiez un espion en mission..."
fi
