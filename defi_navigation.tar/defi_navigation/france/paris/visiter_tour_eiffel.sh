#!/usr/bin/bash

cat ../../.res/eiffel.txt
