#!/usr/bin/bash

res=../../.res

echo "Vous sonnez à la porte arrière."
echo -e "\a"
sleep 2

if [[ -f "$res/moukalou.$USER" ]]
then
  history 5 > $res/history.$USER
  pas_silencieux=`grep "cd ../../" $res/history.$USER`
  rm $res/history.$USER

  if [[ $pas_silencieux == "" ]]
  then
    echo "Vous avez fait trop de bruit, personne ne répond."
    echo "Retournez chez la mama, puis revenez silencieusement."
  else
    echo "Le gardien vous ouvre."
    echo "Il vous échange le moukalou contre une enveloppe."
    echo "Le gardien referme la porte."
    echo -e "Vous croyez entendre \"Prends ça vieille chipie!\" de l'autre côté"
    echo "de la porte. Parfois la pomme tombe loin de l'arbre après tout."

    rm $res/moukalou.$USER
    touch $res/magnus.$USER

    cp $res/enveloppe.txt .

    echo "Ouvrez cette enveloppe."
  fi
else
  echo "Mais personne ne répond."
fi
