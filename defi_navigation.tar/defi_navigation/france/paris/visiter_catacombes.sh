#!/usr/bin/bash

echo "Vous visitez les catacombes et repartez avec une réflexion sur la vie et la mort."
echo "Est-ce que ça vaut la peine de retrouver cette fameuse clé?"
echo "Qui êtes-vous? Qu'est-ce que cette entité qui vous écrit sur cette console?"
