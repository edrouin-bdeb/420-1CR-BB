#!/usr/bin/bash 

res=../../.res

if [[ -f "$res/nombre1.$USER" && -f "$res/nombre2.$USER" && -f "$res/nombre3.$USER" ]]
then
  echo "Dans la gare, vous remarquez tout de suite le tableau illustrant un"
  echo "coffre fort. Il est suspendu bien haut derrière le comptoir de la"
  echo "billetterie. Ça ne sera pas de la tarte. Il vous faudra revenir de"
  echo "nuit alors que la gare sera pratiquement déserte et que la billetterie"
  echo "sera fermée."
  echo ""
  echo "Vous décidez d'aller visiter le Chinatown en attendant. Vous sortez"
  echo "dehors et au moment où vous traversez la rue, vous êtes heurté par"
  echo "quelque chose. Vous perdez connaissance et vous vous réveillez dans"
  echo "un endroit inconnu. Vous allez devoir retrouver votre chemin jusqu'au"
  echo "Chinatown."
  rm $res/*.$USER
  cp $res/visiter_chinatown.sh .
  cd /tmp
else
  echo "La gare est bondée de gens qui attendent un train. C'est très bruyant."
  echo "Vous sifflotez votre mélodie préférée, mais ne l'entendez pas. Déçu,"
  echo "vous décidez de retourner à l'extérieur pour qu'on apprécie davantage"
  echo "votre talent."
fi
