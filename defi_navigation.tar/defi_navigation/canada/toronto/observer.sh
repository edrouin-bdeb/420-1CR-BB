#!/usr/bin/bash 

res=../../.res

if [[ -f "$res/toronto.$USER" ]]
then
  echo "Un individu mesurant 2.2 mètres portant un maillot de bain"
  echo "et tenant une affiche sur laquelle est inscrit"
  echo ""
  echo -e "     \"Fausse identité de $PRENOM Bourne\""
  echo ""
  echo "vous attend dans la section des arrivées."
  echo ""
  echo "Dès que vos regards se croisent, l'individu crie de toutes"
  echo -e "ses forces: \"PAR ICI $PRENOM!!!\""
  echo ""
  echo "Alors que vous vous dites que la discrétion est un art"
  echo "qui se perd, vous réalisez que vous avez marché jusqu'à"
  echo "cet individu bien malgré vous. Il vous sert la main."
  echo ""
  echo -e "L'individu: \"BIENVENUE AU CANADA $PRENOM\""
  echo ""
  echo "Il doit être vraiment heureux de vous voir!"
  echo "L'individu vous demande de le suivre. Vous le suivez donc."
  echo "En chemin, vous apprenez que la clé USB est cachée dans"
  echo "un coffre fort derrière un tableau représentant un coffre"
  echo "fort accroché dans le hall de la Pacific Central Station."
  echo "Vous apprenez aussi que chacun des trois nombres de la"
  echo "combinaison du coffre fort caché derrière le tableau de"
  echo "coffre fort sont cachés eux aussi dans des coffres forts."
  echo "Vous apprenez que ces coffres se trouvent dans la maison"
  echo "d'Al Capone, dans l'université fondée par William Barton"
  echo "Rogers et dans le Palais Bahia."
  echo ""
  echo "Lorsque vous arrivez enfin à l'endroit que l'individu avait"
  echo "soigneusement choisi pour vous faire toutes ces révélations,"
  echo "il réalise qu'il n'a plus rien à vous dire. Il vous remet"
  echo "3 clés et vous souhaite bonne chance."

  rm $res/toronto.$USER
  ./$res/coffres.sh

  echo "Le coffre: Pacific Central Station" >note_mentale.txt
  echo "La combinaison: maison d'Al Capone, université de Willian Barton Rogers, Palais Bahia" >>note_mentale.txt
else
  echo "Vous observez que Toronto est une mégalopole remplie de gens d'affaires."
  echo "Vous vous ennuyez..."
fi
