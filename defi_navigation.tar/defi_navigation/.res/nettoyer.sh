#!/usr/bin/bash 

res=../../.res

rm $res/*.$USER
rm -f ../../etats-unis/boston/ouvrir_coffre.sh
rm -f ../../etats-unis/chicago/ouvrir_coffre.sh
rm -f ../../maroc/marrakesh/ouvrir_coffre.sh
rm -f ../../canada/vancouver/visiter_chinatown.sh
rm -f ../../canada/toronto/note_mentale.txt
rm -f ../../france/paris/enveloppe.txt
rm -f ../../italie/turin/papier.txt
rm -f ~/carnet.txt
