#!/usr/bin/bash 

res=../../.res

echo "Après plusieurs heures de recherche sur le campus, vous trouvez"
echo "un minuscule coffre à l'intérieur d'un énorme bouquin poussiéreux"
echo "traitant de l'utilisation des mollusques dans la tradition"
echo "culinaire du 19e siècle en Nouvelle-Angleterre. Oui, vous avez"
echo "cherché plusieurs heures."
echo ""
echo "Vous essayez une à une les clés obtenues à Toronto. La dernière"
echo "ouvre le petit coffret."
echo ""
read -n 1 -s -r -p "Suspense... (appuyez sur une touche)"
echo -e "\n"
sleep 2
echo "Suspense prolongé... (imaginez une trame sonore inquiétante)"
sleep 4

if [[ -f $res/nombre1.$USER ]]
then
  echo "Il est vide!!!! Mais comment est-ce possible?!?!?"
else
  echo "Il contient un petit bout de papier sur lequel est écrit un"
  echo "nombre que vous mémorisez, mais que nous n'afficherons pas"
  echo "à l'écran pour des raisons de sécurité nationale."
  touch $res/nombre1.$USER
fi
