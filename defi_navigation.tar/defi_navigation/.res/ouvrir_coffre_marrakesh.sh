#!/usr/bin/bash 

res=../../.res

echo "Le Palais est magnifique. Vous questionnez les gens qui se"
echo "trouvent sur place à savoir s'ils ont vu un coffre quelque"
echo "part sur les lieux. Une vieille dame vous indique une porte"
echo "verrouillée depuis plusieurs années."
echo ""
echo "Vous testez une de vos clés sur la serrure qui cède immédiatement."

if [[ -f $res/nombre3.$USER ]]
then
  echo "La porte donne sur une minuscule pièce vide, probablement"
  echo "un endroit où on range les balais puisqu'il y a un peu de"
  echo "sable sur le sol. Pourquoi cet endroit vous semble-t-il si"
  echo "familier? Bizarre."
else
  echo "La porte ouvre sur une minuscule pièce vide. Au sol, un petit"
  echo "tas de sable sur lequel on a tracé un nombre du doigt."
  echo ""
  echo "Vous mémorisez ce nombre puis balayez le sable du pied."
  touch $res/nombre3.$USER
fi
