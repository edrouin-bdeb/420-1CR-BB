#!/usr/bin/bash 

res=../../.res

echo "Vous vous rendez au manoir d'Al Capone et payez pour la visite"
echo "non guidée. En entrant dans une des pièces de la résidence, vous"
echo "trébuchez sur un fauteuil et tombez sur le sol près du foyer."
echo "En vous relevant, vous remarquez que le plancher grince à cet"
echo "endroit. Avec un peu de travail, vous parvenez à déloger une"
echo "planche et découvrez une cavité qui cache un coffret que vous"
echo "parvenez à ouvrir avec une des clés reçues à Toronto."
echo ""
sleep 5

if [[ -f $res/nombre2.$USER ]]
then
  echo -e "Le coffre contient une petite note: \"Vous allez finir par"
  echo -e "vous faire mal à force de trébucher sur ce fauteuil.\""
else
  echo "Il contient un petit bout de papier sur lequel est écrit un"
  echo "nombre que vous mémorisez, mais que nous n'afficherons pas"
  echo "à l'écran de peur que des gens malintentionnés en prennent"
  echo "connaissance."
  touch $res/nombre2.$USER
fi
