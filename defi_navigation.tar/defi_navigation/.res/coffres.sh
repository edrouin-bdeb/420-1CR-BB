#!/usr/bin/bash 

res=../../.res

cp $res/ouvrir_coffre_chicago.sh ../../etats-unis/chicago/ouvrir_coffre.sh
cp $res/ouvrir_coffre_boston.sh ../../etats-unis/boston/ouvrir_coffre.sh
cp $res/ouvrir_coffre_marrakesh.sh ../../maroc/marrakesh/ouvrir_coffre.sh
