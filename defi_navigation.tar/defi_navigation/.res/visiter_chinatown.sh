#!/usr/bin/bash 

res=../../.res

if [[ -f $res/mogwais.$USER && -f $res/producteur.$USER ]]
then
  echo "Vous retournez chez l'antiquaire. Convaincu que vous travaillez"
  echo "pour la police, il fait maintenant semblant de ne pas vous"
  echo "reconnaître et vous demande de cesser de l'importuner."
elif [[ -f $res/mogwais.$USER ]]
then
  echo "Vous questionnez l'antiquaire sur la provenance des créatures"
  echo "dans la cage. Il dit qu'elles arrivent de Chine par bateau."
  echo "C'est un vieil ami de Pékin qui lui vend."
  echo ""
  echo "Vous le remerciez puis quittez la boutique avant de vous"
  echo "réveiller ailleurs encore une fois..."
  touch $res/producteur.$USER
else
  echo "Alors que vous visitez les commerces du Chinatown, vous entrez"
  echo "chez un antiquaire. Le commerce a une forte odeur d'encens."
  echo "Vous remarquez tout de suite un tableau identique à celui de la"
  echo "gare, posé juste à côté d'une cage contenant de petites créatures"
  echo "poilues vraisemblablement appelées mogwais. Vous vous informez"
  echo "sur le tableau auprès de l'antiquaire."
  echo ""
  echo "L'antiquaire vous certifie qu'il s'agit bel et bien du tableau"
  echo "original qui se trouvait à la gare alors qu'une copie le remplace"
  echo "là-bas. Mais... c'est que c'est complètement farfelu!"
  echo ""
  echo "Bien sûr que non vous assure-t-il! Qui serait assez fou pour"
  echo "laisser une oeuvre d'aussi grande qualité exposée en plein jour"
  echo "et au grand public? Le soleil ou un passant aurait tôt fait de"
  echo "l'abîmer. Et qui ne voudrait pas en tirer un bon profit?"
  echo ""
  echo "Eum... Vous vous dites que l'antiquaire marque un bon point en"
  echo "découvrant quelques Rembrandt accrochés à un mur un peu plus loin."
  echo ""
  read -n 1 -r -s -p "Vous réfléchissez... (appuyez sur une touche)"
  echo ""
  echo "L'antiquaire vous sort de votre réflexion en vous demandant si la"
  echo "toile vous intéresse. Vous lui dites qu'à moins qu'elle ne cache"
  echo "un coffre, pas vraiment."
  echo ""
  echo "L'antiquaire, tout souriant, déplace le tableau. Un coffre se"
  echo "trouve derrière! Mais?!?! Vous testez votre combinaison avec peu"
  echo "d'espoir, mais le coffre s'ouvre. À l'intérieur, vous trouvez un"
  echo "petit carnet de notes. Surpris, l'antiquaire vous le cède non"
  echo "sans négocier."
  cp $res/carnet.txt ~/carnet.txt 
  echo "L'encens vous fait tourner la tête. Vous reprenez vos sens dans"
  echo "votre maison!"
  touch $res/mogwais.$USER
  cd ~
fi
