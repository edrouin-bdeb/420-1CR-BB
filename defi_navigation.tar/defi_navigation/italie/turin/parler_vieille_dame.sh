#!/usr/bin/bash

echo "La veille dame s'enfuit en serrant son sac et en vous invectivant!"
