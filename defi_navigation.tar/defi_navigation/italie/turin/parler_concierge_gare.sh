#!/usr/bin/bash

echo "Scusa non parlo francese. Sembri perso. Ho lavoro."
