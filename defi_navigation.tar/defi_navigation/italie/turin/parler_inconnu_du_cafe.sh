#!/usr/bin/bash

res=../../.res

echo "Le vieil individu barbu et drôlement habillé (on dirait un druide!) lèvent les yeux vers vous."

if [[ -f "../../mission.txt" ]]
then
  echo "L'individu vous écoute, mais fait mine de ne rien comprendre de ce que vous dites."
  echo "Vous insistez."
  echo "Il dit qu'il ne peut pas faire confiance à un espion qui laisse des traces, puis il s'enfuit."
  echo "Qu'est-ce qu'il entend par laisser des traces? Quelles traces?"
else
  echo "L'individu vous glisse un papier sous la table. Il est discret et écrit super vite, apparemment."

  cp $res/papier.txt .
  touch $res/papier.$USER

  echo "Lisez le papier."
fi
