#!/usr/bin/bash

echo "Vous parlez de tout et de rien pendant des heures avec un dénommé Franck."
echo "Bien que sympathique, Franck ne vous apprend absolument rien d'utile"
echo "sauf peut-être que chez les hippocampes, c'est au mâle que reviennent"
echo "toutes les responsabilités parentales."
echo ""
echo "Pas certain que ça vous fasse progresser dans votre mission..."
