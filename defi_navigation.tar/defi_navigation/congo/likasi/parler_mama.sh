#!/usr/bin/bash

res=../../.res

if [[ -f "$res/moukalou.$USER" ]]
then
  echo "Il n'y a personne ici."
  echo "Gardez davantage le focus sur votre mission svp!"
else
  echo "À l'entrée de la ville, vous rencontrez une femme d'un certain âge."
  echo "Elle vous attend avec un plat dans les mains."

  if [[ -f "$res/mama.$USER" ]]
  then
    echo ""
    echo -e " \"J'ai préparé ce moukalou pour mon fils. J'y ai mis tout mon amour."
    echo ""
    echo "  Je suis tellement fière de lui depuis qu'il a obtenu son brevet de pilote."
    echo "  Heureusement qu'il n'est pas comme son vaurien de grand frère qui gâche"
    echo "  sa vie en tant que gardien de sécurité quelque part en Europe, du moins,"
    echo "  à ce qu'on m'a dit."
    echo ""
    echo -e "  Merci à vous de bien vouloir lui rapporter ce plat.\""
    rm $res/mama.$USER
    touch $res/moukalou.$USER
  else
    echo "Elle vous remet le plat que vous engouffrez immédiatement."
    echo "Quand on a faim, on a faim!"
    echo "La dame vous dévisage et quitte en grommelant."
    sleep 5
    echo "Elle revient avec un nouveau plat quelques heures plus tard."
    echo "Vous réalisez alors que vous avez eu un moment d'absence plutôt gênant."
  fi
fi
