#!/bin/bash

addgroup duo

personnages=("celebrex" "musculator")

for personnage in "${personnages[@]}"; do
    echo "Création du personnage $personnage"
    adduser -g "$personnage" -s /bin/bash -D -H -G duo $personnage

    while true; do
        read -sp "Mot de passe pour $personnage: " motdepasse
        echo
        read -sp "Confirmation du mot de passe: " confirmation
        echo

        if [ "$confirmation" == "$motdepasse" ]; then
            echo "$personnage:$motdepasse" | chpasswd >/dev/null 2>&1
            echo "Mot de passe changé pour $personnage."
            break
        else
            echo "Les mots de passe sont différents. Réessayez."
        fi
    done
done

mkdir /astoria
chgrp duo /astoria
